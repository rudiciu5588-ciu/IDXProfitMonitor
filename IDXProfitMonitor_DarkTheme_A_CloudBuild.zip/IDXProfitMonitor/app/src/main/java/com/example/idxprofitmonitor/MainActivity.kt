package com.example.idxprofitmonitor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Stock(val ticker: String, val company: String, val price: String, val change: String, val positive: Boolean)

private val demoStocks = listOf(
    Stock("BBCA", "Bank Central Asia", "9.725", "+1,04%", true),
    Stock("BREN", "Barito Renewables Energy", "7.150", "-0,69%", false),
    Stock("DEWA", "Darma Henwa", "438", "+2,82%", true),
    Stock("ENRG", "Energi Mega Persada", "1.245", "+1,63%", true),
    Stock("RAJA", "Rukun Raharja", "3.180", "-0,31%", false),
    Stock("TINS", "Timah", "1.090", "+0,93%", true)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IDXApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IDXApp() {
    var selected by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    val tabs = listOf("Ringkasan", "Watchlist", "Scanner", "Portofolio")
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF35D39A),
        secondary = Color(0xFF63B3FF),
        background = Color(0xFF080D12),
        surface = Color(0xFF121A23),
        onBackground = Color(0xFFE8EEF5),
        onSurface = Color(0xFFE8EEF5)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("IDX PROFIT MONITOR", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("PEMANTAU SAHAM BEI  •  MODE DEMO", fontSize = 10.sp, color = Color(0xFF8B9AAA))
                        }
                    },
                    actions = { IconButton(onClick = { }) { Icon(Icons.Default.Notifications, "Notifikasi") } }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF111923), contentColor = Color(0xFFE8EEF5)) {
                    tabs.forEachIndexed { index, title ->
                        val icon = when(index) {
                            0 -> Icons.Default.Home
                            1 -> Icons.Default.Star
                            2 -> Icons.Default.Search
                            else -> Icons.Default.AccountBalanceWallet
                        }
                        NavigationBarItem(
                            selected = selected == index,
                            onClick = { selected = index },
                            icon = { Icon(icon, contentDescription = title) },
                            label = { Text(title, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            when(selected) {
                0 -> Overview(Modifier.padding(padding))
                1 -> Watchlist(Modifier.padding(padding), query) { query = it }
                2 -> Scanner(Modifier.padding(padding))
                else -> Portfolio(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun Overview(modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF125B45)), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("IHSG  •  INDEKS HARGA SAHAM GABUNGAN", color = Color.White.copy(alpha = .8f), fontSize = 11.sp)
                    Text("7.250,00", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("+0,45%  •  DATA ILUSTRASI", color = Color(0xFFB9F6D3), fontSize = 12.sp)
                }
            }
        }
        item { Text("PANTAUAN PASAR", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9EADBC)) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricCard("Top Gainers", "+2,82%", Color(0xFF167A4A), Modifier.weight(1f))
                MetricCard("Top Losers", "-0,69%", Color(0xFFC0392B), Modifier.weight(1f))
                MetricCard("Volume", "Tinggi", Color(0xFF375A9E), Modifier.weight(1f))
            }
        }
        item { Text("WATCHLIST PILIHAN", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9EADBC)) }
        items(demoStocks.take(4)) { StockRow(it) }
        item {
            Text("Catatan: seluruh angka pada versi awal ini adalah data contoh, bukan harga pasar saat ini.",
                color = Color(0xFF9A5B00), fontSize = 12.sp)
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = color.copy(alpha = .10f))) {
        Column(Modifier.padding(10.dp)) {
            Text(title, fontSize = 10.sp, color = Color.Gray)
            Text(value, fontWeight = FontWeight.Bold, color = color, fontSize = 14.sp)
        }
    }
}

@Composable
fun Watchlist(modifier: Modifier = Modifier, query: String, onQuery: (String) -> Unit) {
    val filtered = demoStocks.filter { it.ticker.contains(query, true) || it.company.contains(query, true) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(query, onQuery, modifier = Modifier.fillMaxWidth(),
            label = { Text("Cari kode atau nama saham") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(filtered) { StockRow(it) } }
    }
}

@Composable
fun StockRow(stock: Stock) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17222D))) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stock.ticker, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(stock.company, color = Color.Gray, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Rp ${stock.price}", fontWeight = FontWeight.SemiBold)
                Text(stock.change, color = if(stock.positive) Color(0xFF16834A) else Color(0xFFC0392B),
                    fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

private data class TechnicalSnapshot(
    val ticker: String,
    val rsi: Double,
    val smaShort: Double,
    val smaLong: Double,
    val macdLine: Double,
    val signal: String
)

// Data penutupan berikut hanya data sintetis untuk demonstrasi perhitungan.
private val demoHistory = mapOf(
    "BBCA" to listOf(9500.0, 9520.0, 9480.0, 9600.0, 9630.0, 9580.0, 9700.0, 9725.0, 9760.0, 9800.0, 9780.0, 9850.0, 9900.0, 9870.0, 9920.0, 9970.0),
    "BREN" to listOf(7200.0, 7180.0, 7150.0, 7120.0, 7100.0, 7140.0, 7110.0, 7080.0, 7060.0, 7090.0, 7120.0, 7100.0, 7150.0, 7130.0, 7160.0, 7150.0),
    "DEWA" to listOf(390.0, 395.0, 392.0, 400.0, 405.0, 402.0, 410.0, 415.0, 420.0, 418.0, 425.0, 430.0, 428.0, 435.0, 440.0, 438.0),
    "ENRG" to listOf(1100.0, 1110.0, 1090.0, 1120.0, 1130.0, 1125.0, 1140.0, 1150.0, 1160.0, 1155.0, 1170.0, 1180.0, 1190.0, 1200.0, 1230.0, 1245.0),
    "RAJA" to listOf(3200.0, 3190.0, 3180.0, 3170.0, 3160.0, 3180.0, 3190.0, 3175.0, 3160.0, 3150.0, 3160.0, 3170.0, 3190.0, 3200.0, 3190.0, 3180.0),
    "TINS" to listOf(1040.0, 1045.0, 1035.0, 1050.0, 1055.0, 1060.0, 1050.0, 1065.0, 1070.0, 1060.0, 1075.0, 1080.0, 1075.0, 1085.0, 1095.0, 1090.0)
)

private fun sma(values: List<Double>, period: Int): Double =
    values.takeLast(period).average()

private fun rsi(values: List<Double>, period: Int = 14): Double {
    val changes = values.zipWithNext { a, b -> b - a }.takeLast(period)
    val gains = changes.filter { it > 0 }.sum() / period
    val losses = -changes.filter { it < 0 }.sum() / period
    if (losses == 0.0) return if (gains == 0.0) 50.0 else 100.0
    val rs = gains / losses
    return 100.0 - (100.0 / (1.0 + rs))
}

private fun ema(values: List<Double>, period: Int): Double {
    val k = 2.0 / (period + 1)
    return values.drop(1).fold(values.first()) { acc, value -> value * k + acc * (1 - k) }
}

private fun technicalSnapshot(ticker: String, values: List<Double>): TechnicalSnapshot {
    val short = sma(values, 5)
    val long = sma(values, 10)
    val macd = ema(values, 5) - ema(values, 10)
    val label = when {
        rsi(values) >= 70 -> "Momentum tinggi — waspadai volatilitas"
        rsi(values) <= 30 -> "Momentum lemah — perlu kajian lanjut"
        short > long && macd > 0 -> "Tren positif pada data demo"
        short < long && macd < 0 -> "Tren negatif pada data demo"
        else -> "Belum ada konfirmasi tren"
    }
    return TechnicalSnapshot(ticker, rsi(values), short, long, macd, label)
}

@Composable
fun Scanner(modifier: Modifier = Modifier) {
    val snapshots = demoHistory.map { (ticker, values) -> technicalSnapshot(ticker, values) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("SCANNER TEKNIKAL", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("RSI • SMA 5/10 • MACD", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF332817))) {
            Text(
                "MODE DEMO: data harga sintetis, bukan data BEI terkini. Label hanya untuk belajar membaca indikator, bukan rekomendasi transaksi.",
                Modifier.padding(12.dp), color = Color(0xFFFFD28A), fontSize = 12.sp
            )
        }
        Spacer(Modifier.height(12.dp))
        snapshots.forEach { item ->
            Card(Modifier.fillMaxWidth().padding(bottom = 9.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF17222D))) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(item.ticker, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                            modifier = Modifier.weight(1f))
                        Text("RSI ${"%.1f".format(item.rsi)}", fontWeight = FontWeight.SemiBold)
                    }
                    Text("SMA 5: ${"%.2f".format(item.smaShort)}  •  SMA 10: ${"%.2f".format(item.smaLong)}",
                        fontSize = 12.sp, color = Color.Gray)
                    Text("MACD (EMA 5-10): ${"%.2f".format(item.macdLine)}",
                        fontSize = 12.sp, color = Color.Gray)
                    Text(item.signal, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
fun ScannerCard(title: String, detail: String) {
    Card {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(detail, color = Color.Gray, fontSize = 13.sp)
        }
    }
}

@Composable
fun Portfolio(modifier: Modifier = Modifier) {
    var ticker by remember { mutableStateOf("") }
    var lots by remember { mutableStateOf("") }
    var buyPrice by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PORTOFOLIO SIMULASI", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Masukkan posisi untuk menghitung nilai modal. Data tersimpan sementara selama aplikasi terbuka.")
        OutlinedTextField(ticker, { ticker = it.uppercase() }, label = { Text("Kode saham") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(lots, { lots = it }, label = { Text("Jumlah lot") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(buyPrice, { buyPrice = it }, label = { Text("Harga beli per saham (Rp)") }, modifier = Modifier.fillMaxWidth())
        val total = (lots.toLongOrNull() ?: 0L) * (buyPrice.toLongOrNull() ?: 0L) * 100L
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF4EF))) {
            Column(Modifier.padding(16.dp)) {
                Text("Estimasi modal")
                Text("Rp ${"%,d".format(total)}", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text("Belum termasuk biaya transaksi.", fontSize = 11.sp, color = Color.Gray)
            }
        }
        Text("Fitur simpan transaksi, harga jual, dan untung/rugi akan ditambahkan pada tahap berikutnya.",
            fontSize = 12.sp, color = Color.Gray)
    }
}
