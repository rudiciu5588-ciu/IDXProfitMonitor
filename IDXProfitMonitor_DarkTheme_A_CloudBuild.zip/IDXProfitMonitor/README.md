# IDX Profit Monitor — Dark Trading UI

Proyek Android native menggunakan Kotlin + Jetpack Compose.

## Fitur prototipe (tema A: trading profesional gelap)
- Dashboard ringkasan pasar dengan angka ilustrasi.
- Watchlist dan pencarian saham.
- Scanner edukasi dengan perhitungan RSI, SMA 5/10, dan MACD dari data sintetis.
- Kalkulator modal portofolio.

## Status data
Aplikasi **belum terhubung ke data BEI live**. Harga dan histori yang tampil adalah data contoh/sintetis. Scanner hanya mendemonstrasikan rumus indikator dan tidak menghasilkan rekomendasi investasi.

Untuk data live/historis, pilih penyedia data yang memiliki hak distribusi dan API untuk saham Indonesia. Integrasi memerlukan endpoint, dokumentasi API, dan kredensial. Simpan API key di backend, bukan di aplikasi Android.

## Membuka proyek
1. Instal Android Studio versi stabil.
2. Pilih Open dan pilih folder `IDXProfitMonitor`.
3. Tunggu Gradle Sync.
4. Jalankan pada emulator atau HP Android.

## Membuat APK debug
Di terminal folder proyek, jalankan:
```bash
gradle assembleDebug
```
APK debug akan dibuat di `app/build/outputs/apk/debug/app-debug.apk`.

Untuk rilis publik, buat signing key sendiri melalui Android Studio > Build > Generate Signed Bundle / APK. Jangan membagikan signing key atau password.

## Tampilan
Versi ini memakai tema gelap profesional: latar navy/charcoal, panel gelap, aksen hijau, dan navigasi bawah. Angka pasar tetap data demo/sintetis; belum ada koneksi harga BEI live.


## Build APK tanpa komputer (pakai HP Android)
1. Ekstrak ZIP ini di HP.
2. Buat repository baru di GitHub, lalu unggah seluruh isi folder `IDXProfitMonitor` (termasuk folder tersembunyi `.github`).
3. Buka tab **Actions** pada repository dan pilih workflow **Build Android APK**.
4. Tekan **Run workflow** jika belum berjalan otomatis.
5. Setelah selesai, buka hasil run dan unduh artifact **IDXProfitMonitor-debug-apk**.
6. Ekstrak artifact ZIP, lalu buka `app-debug.apk` untuk memasang.

Catatan: GitHub Actions memerlukan akun GitHub. APK debug ini untuk pemasangan/pengujian pribadi. Data harga pada aplikasi masih demo, bukan harga BEI live.
